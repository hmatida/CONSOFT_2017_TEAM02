#Some setup information :).

##Spring JPA Setup
You need to change the **application.properties** and configure the login, password and url of your database. 
  	

